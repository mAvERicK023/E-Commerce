<?php
require('./top.php')
?>

<h4 style="color: orange;">Your order has been placed successfully!</h4>

<?php require('./footer.php') ?>